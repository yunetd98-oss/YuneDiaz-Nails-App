YUNE DÍAZ NAILS v3 - PROYECTO ANDROID

Compatibilidad: Android 8.0 (API 26) o superior.

Abrir en Android Studio y ejecutar Build > Build APK(s).
El APK de depuración quedará en app/build/outputs/apk/debug/app-debug.apk.

Este proyecto envuelve la aplicación web v2 en una app Android nativa mediante WebView.
